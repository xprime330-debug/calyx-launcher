package com.calyx.launcher

import android.annotation.SuppressLint
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.recyclerview.widget.RecyclerView

/** The app drawer list, with simple search filtering. */
class DrawerAdapter(
    private val all: List<AppInfo>,
    private val textColor: Int,
    private val onClick: (AppInfo) -> Unit,
    private val onLongClick: (AppInfo, View) -> Unit
) : RecyclerView.Adapter<DrawerAdapter.VH>() {

    class VH(val box: FrameLayout) : RecyclerView.ViewHolder(box)

    private var shown: List<AppInfo> = all

    @SuppressLint("NotifyDataSetChanged")
    fun filter(query: String) {
        val q = query.trim()
        shown = if (q.isEmpty()) all else all.filter { it.label.contains(q, ignoreCase = true) }
        notifyDataSetChanged()
    }

    fun firstShown(): AppInfo? = shown.firstOrNull()

    override fun getItemCount(): Int = shown.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val box = FrameLayout(ctx)
        box.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        box.setPadding(0, ctx.dp(10), 0, ctx.dp(10))
        return VH(box)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ctx = holder.box.context
        val app = shown[position]
        holder.box.removeAllViews()
        val cell = makeAppCell(ctx, app, textColor, 56, labels = true, shadow = false)
        cell.setOnClickListener { onClick(app) }
        cell.setOnLongClickListener {
            onLongClick(app, cell)
            true
        }
        holder.box.addView(
            cell,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
    }
}
