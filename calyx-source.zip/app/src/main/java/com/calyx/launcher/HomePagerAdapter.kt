package com.calyx.launcher

import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.GridLayout
import androidx.recyclerview.widget.RecyclerView

/** One page per list of apps; each page is a grid of icons. */
class HomePagerAdapter(
    private val columns: Int,
    private val rows: Int,
    private val pages: List<List<AppInfo>>,
    private val onClick: (AppInfo) -> Unit,
    private val onLongClick: (AppInfo, View) -> Unit,
    private val onBackgroundLongClick: () -> Unit
) : RecyclerView.Adapter<HomePagerAdapter.VH>() {

    class VH(val frame: FrameLayout) : RecyclerView.ViewHolder(frame)

    override fun getItemCount(): Int = pages.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val frame = FrameLayout(parent.context)
        frame.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        frame.setOnLongClickListener {
            onBackgroundLongClick()
            true
        }
        return VH(frame)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ctx = holder.frame.context
        holder.frame.removeAllViews()

        val grid = GridLayout(ctx)
        grid.columnCount = columns
        grid.rowCount = rows
        grid.setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(8))

        val apps = pages[position]
        val slots = columns * rows
        for (i in 0 until slots) {
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(i / columns, 1f),
                GridLayout.spec(i % columns, 1f)
            )
            lp.width = 0
            lp.height = 0
            if (i < apps.size) {
                val app = apps[i]
                val cell = makeAppCell(ctx, app, Color.WHITE, 58, labels = true, shadow = true)
                cell.setOnClickListener { onClick(app) }
                cell.setOnLongClickListener {
                    onLongClick(app, cell)
                    true
                }
                grid.addView(cell, lp)
            } else {
                // Empty slot keeps every row the same height.
                grid.addView(View(ctx), lp)
            }
        }

        holder.frame.addView(
            grid,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
    }
}
