package com.calyx.launcher

import android.graphics.drawable.GradientDrawable

object Themes {
    const val LIGHT = 0
    const val DARK = 1
    const val COLORFUL = 2

    class Palette(
        val text: Int,
        val subtext: Int,
        val scrim: Int,
        val dock: Int,
        val search: Int,
        val gradient: IntArray?,
        val lightDialog: Boolean
    ) {
        fun drawerBackground(): GradientDrawable {
            val g = gradient
            return if (g != null) {
                GradientDrawable(GradientDrawable.Orientation.TL_BR, g)
            } else {
                GradientDrawable().also { it.setColor(scrim) }
            }
        }
    }

    fun get(theme: Int): Palette = when (theme) {
        LIGHT -> Palette(
            text = 0xFF1B1B1F.toInt(),
            subtext = 0xFF6A6A75.toInt(),
            scrim = 0xEBF5F5F8.toInt(),
            dock = 0xB3FFFFFF.toInt(),
            search = 0xFFE4E4EB.toInt(),
            gradient = null,
            lightDialog = true
        )
        COLORFUL -> Palette(
            text = 0xFFFFFFFF.toInt(),
            subtext = 0xFFEDE7FF.toInt(),
            scrim = 0xF2C44DFF.toInt(),
            dock = 0x66FFFFFF.toInt(),
            search = 0x44FFFFFF.toInt(),
            gradient = intArrayOf(0xF2FF6B6B.toInt(), 0xF2C44DFF.toInt(), 0xF23D6BFF.toInt()),
            lightDialog = false
        )
        else -> Palette(
            text = 0xFFFFFFFF.toInt(),
            subtext = 0xFFB5B5C0.toInt(),
            scrim = 0xEB0E0E12.toInt(),
            dock = 0x802A2A30.toInt(),
            search = 0xFF26262C.toInt(),
            gradient = null,
            lightDialog = false
        )
    }
}
