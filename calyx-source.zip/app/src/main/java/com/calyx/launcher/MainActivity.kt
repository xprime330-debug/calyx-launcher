package com.calyx.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var palette: Themes.Palette

    private lateinit var root: GestureLayout
    private lateinit var mainColumn: LinearLayout
    private lateinit var pager: ViewPager2
    private lateinit var dots: PageDots
    private lateinit var dock: LinearLayout
    private lateinit var drawer: View
    private lateinit var drawerContent: LinearLayout
    private lateinit var search: EditText
    private lateinit var drawerList: RecyclerView

    private var allApps: List<AppInfo> = emptyList()
    private var drawerAdapter: DrawerAdapter? = null
    private var drawerOpen = false
    private var listAtTopOnDown = true

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            reloadApps()
        }
    }

    private companion object {
        const val ROWS = 5
        const val DOCK_MAX = 4
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)
        palette = Themes.get(prefs.theme)

        root = findViewById(R.id.root)
        mainColumn = findViewById(R.id.mainColumn)
        pager = findViewById(R.id.pager)
        dots = findViewById(R.id.dots)
        dock = findViewById(R.id.dock)
        drawer = findViewById(R.id.drawer)
        drawerContent = findViewById(R.id.drawerContent)
        search = findViewById(R.id.search)
        drawerList = findViewById(R.id.drawerList)

        drawerList.layoutManager = GridLayoutManager(this, 4)

        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                dots.selected = position
            }
        })

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            mainColumn.setPadding(0, bars.top, 0, bars.bottom)
            drawerContent.setPadding(
                dp(16),
                bars.top + dp(12),
                dp(16),
                maxOf(bars.bottom, ime.bottom)
            )
            insets
        }

        root.gestureStartListener = {
            listAtTopOnDown = !drawerList.canScrollVertically(-1)
        }
        root.swipeUpListener = {
            if (!drawerOpen) openDrawer(false)
        }
        root.swipeDownListener = { handleSwipeDown() }
        root.doubleTapListener = {
            if (!drawerOpen) openDrawer(true)
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                drawerAdapter?.filter(s?.toString() ?: "")
            }

            override fun afterTextChanged(s: Editable?) {}
        })
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH) {
                drawerAdapter?.firstShown()?.let { launch(it) }
                true
            } else {
                false
            }
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        applyTheme()
        reloadApps()
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(packageReceiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Home button pressed while already on home.
        if (drawerOpen) closeDrawer(true) else pager.setCurrentItem(0, true)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer(true) else pager.setCurrentItem(0, true)
    }

    // ---------------------------------------------------------------- theme

    private fun applyTheme() {
        palette = Themes.get(prefs.theme)

        drawer.background = palette.drawerBackground()

        val searchBg = GradientDrawable()
        searchBg.cornerRadius = dp(16).toFloat()
        searchBg.setColor(palette.search)
        search.background = searchBg
        search.setTextColor(palette.text)
        search.setHintTextColor(palette.subtext)

        val dockBg = GradientDrawable()
        dockBg.cornerRadius = dp(30).toFloat()
        dockBg.setColor(palette.dock)
        dock.background = dockBg

        dots.dotColor = Color.WHITE

        if (allApps.isNotEmpty()) setupDrawerAdapter()
    }

    private fun chooseTheme(theme: Int) {
        prefs.theme = theme
        applyTheme()
    }

    // ----------------------------------------------------------------- data

    private fun reloadApps() {
        allApps = AppLoader.load(this)
        seedDefaults()
        renderHome()
        renderDock()
        setupDrawerAdapter()
    }

    /** First run only: put sensible apps on the home screen and dock. */
    private fun seedDefaults() {
        if (prefs.seeded || allApps.isEmpty()) return

        fun find(intent: Intent): String? {
            val info = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                ?: return null
            val pkg = info.activityInfo.packageName
            return allApps.firstOrNull { it.component.packageName == pkg }?.key
        }

        var dockKeys = listOfNotNull(
            find(Intent(Intent.ACTION_DIAL)),
            find(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))),
            find(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))),
            find(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        ).distinct()

        if (dockKeys.isEmpty()) dockKeys = allApps.take(DOCK_MAX).map { it.key }

        var homeKeys = listOfNotNull(
            find(Intent(Settings.ACTION_SETTINGS)),
            find(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))),
            find(Intent(AlarmClock.ACTION_SHOW_ALARMS)),
            allApps.firstOrNull { it.component.packageName == "com.android.vending" }?.key
        ).distinct().filter { it !in dockKeys }

        if (homeKeys.size < 8) {
            val extra = allApps.map { it.key }.filter { it !in dockKeys && it !in homeKeys }
            homeKeys = homeKeys + extra.take(8 - homeKeys.size)
        }

        prefs.dockApps = dockKeys
        prefs.homeApps = homeKeys
        prefs.seeded = true
    }

    // --------------------------------------------------------------- render

    private fun renderHome() {
        val byKey = allApps.associateBy { it.key }
        val saved = prefs.homeApps
        val valid = saved.filter { byKey.containsKey(it) }
        if (valid.size != saved.size) prefs.homeApps = valid

        val perPage = prefs.columns * ROWS
        val pages = valid.mapNotNull { byKey[it] }
            .chunked(perPage)
            .ifEmpty { listOf(emptyList<AppInfo>()) }

        val keep = pager.currentItem
        pager.adapter = HomePagerAdapter(
            prefs.columns,
            ROWS,
            pages,
            { app -> launch(app) },
            { app, view -> showAppMenu(app, view, fromDrawer = false, inDock = false) },
            { showSettings() }
        )
        dots.count = pages.size
        val target = keep.coerceAtMost(pages.size - 1)
        pager.setCurrentItem(target, false)
        dots.selected = target
    }

    private fun renderDock() {
        val byKey = allApps.associateBy { it.key }
        val saved = prefs.dockApps
        val valid = saved.filter { byKey.containsKey(it) }
        if (valid.size != saved.size) prefs.dockApps = valid

        dock.removeAllViews()
        for (key in valid) {
            val app = byKey[key] ?: continue
            val cell = makeAppCell(this, app, Color.WHITE, 58, labels = false, shadow = false)
            cell.setOnClickListener { launch(app) }
            cell.setOnLongClickListener {
                showAppMenu(app, cell, fromDrawer = false, inDock = true)
                true
            }
            dock.addView(
                cell,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
    }

    private fun setupDrawerAdapter() {
        val adapter = DrawerAdapter(
            allApps,
            palette.text,
            { app -> launch(app) },
            { app, view -> showAppMenu(app, view, fromDrawer = true, inDock = false) }
        )
        drawerAdapter = adapter
        drawerList.adapter = adapter
        val q = search.text?.toString() ?: ""
        if (q.isNotEmpty()) adapter.filter(q)
    }

    // --------------------------------------------------------------- drawer

    private fun openDrawer(focusSearch: Boolean) {
        if (drawerOpen) return
        drawerOpen = true
        drawer.animate().cancel()
        drawer.visibility = View.VISIBLE
        drawer.alpha = 0f
        drawer.translationY = root.height * 0.12f
        drawer.animate().alpha(1f).translationY(0f).setDuration(220).start()
        if (focusSearch) {
            search.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closeDrawer(animate: Boolean) {
        if (!drawerOpen) return
        drawerOpen = false
        hideKeyboard()
        search.setText("")
        drawer.animate().cancel()
        if (animate) {
            drawer.animate()
                .alpha(0f)
                .translationY(root.height * 0.12f)
                .setDuration(180)
                .withEndAction {
                    if (!drawerOpen) drawer.visibility = View.GONE
                }
                .start()
        } else {
            drawer.visibility = View.GONE
        }
        drawerList.scrollToPosition(0)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    // -------------------------------------------------------------- actions

    private fun launch(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
        closeDrawer(false)
    }

    private fun showAppMenu(app: AppInfo, anchor: View, fromDrawer: Boolean, inDock: Boolean) {
        val popup = PopupMenu(this, anchor)
        val menu = popup.menu
        if (inDock) {
            menu.add(0, 1, 0, "Remove from dock")
        } else if (!fromDrawer) {
            menu.add(0, 1, 0, "Remove from home")
        } else {
            menu.add(0, 2, 0, "Add to home")
            menu.add(0, 3, 0, "Add to dock")
        }
        menu.add(0, 4, 0, "App info")
        menu.add(0, 5, 0, "Uninstall")

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> {
                    if (inDock) {
                        prefs.dockApps = prefs.dockApps.filter { it != app.key }
                        renderDock()
                    } else {
                        prefs.homeApps = prefs.homeApps.filter { it != app.key }
                        renderHome()
                    }
                }
                2 -> {
                    if (!prefs.homeApps.contains(app.key)) {
                        prefs.homeApps = prefs.homeApps + app.key
                        renderHome()
                    }
                    Toast.makeText(this, "Added to home", Toast.LENGTH_SHORT).show()
                }
                3 -> {
                    val current = prefs.dockApps
                    if (current.contains(app.key)) {
                        Toast.makeText(this, "Already in the dock", Toast.LENGTH_SHORT).show()
                    } else if (current.size >= DOCK_MAX) {
                        Toast.makeText(this, "Dock is full", Toast.LENGTH_SHORT).show()
                    } else {
                        prefs.dockApps = current + app.key
                        renderDock()
                        Toast.makeText(this, "Added to dock", Toast.LENGTH_SHORT).show()
                    }
                }
                4 -> {
                    val i = Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", app.component.packageName, null)
                    )
                    safeStart(i)
                }
                5 -> {
                    val i = Intent(
                        Intent.ACTION_DELETE,
                        Uri.parse("package:" + app.component.packageName)
                    )
                    safeStart(i)
                }
            }
            true
        }
        popup.show()
    }

    private fun showSettings() {
        fun mark(on: Boolean) = if (on) "✓   " else "      "
        val t = prefs.theme
        val c = prefs.columns
        val labels = arrayOf(
            mark(t == Themes.LIGHT) + "Light theme",
            mark(t == Themes.DARK) + "Dark theme",
            mark(t == Themes.COLORFUL) + "Colorful theme",
            mark(c == 4) + "4 columns",
            mark(c == 5) + "5 columns",
            "      Change wallpaper",
            "      Default launcher settings"
        )
        val style = if (palette.lightDialog) {
            AlertDialog.THEME_DEVICE_DEFAULT_LIGHT
        } else {
            AlertDialog.THEME_DEVICE_DEFAULT_DARK
        }
        AlertDialog.Builder(this, style)
            .setTitle("Calyx")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> chooseTheme(Themes.LIGHT)
                    1 -> chooseTheme(Themes.DARK)
                    2 -> chooseTheme(Themes.COLORFUL)
                    3 -> {
                        prefs.columns = 4
                        renderHome()
                    }
                    4 -> {
                        prefs.columns = 5
                        renderHome()
                    }
                    5 -> safeStart(
                        Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Select wallpaper")
                    )
                    6 -> safeStart(Intent(Settings.ACTION_HOME_SETTINGS))
                }
            }
            .show()
    }

    private fun handleSwipeDown() {
        if (drawerOpen) {
            if (listAtTopOnDown) closeDrawer(true)
        } else {
            expandNotifications()
        }
    }

    /** Swipe down on the home screen pulls down the notification panel. */
    private fun expandNotifications() {
        try {
            val service = getSystemService("statusbar")
            val cls = Class.forName("android.app.StatusBarManager")
            cls.getMethod("expandNotificationsPanel").invoke(service)
        } catch (e: Exception) {
            // Not allowed on this phone; ignore.
        }
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Not available on this phone", Toast.LENGTH_SHORT).show()
        }
    }
}
