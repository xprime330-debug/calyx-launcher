package com.calyx.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/**
 * Draws any app icon as a rounded square (iOS / One UI style).
 * Adaptive icons are drawn from their raw layers so every icon gets the same shape.
 */
class SquircleIcon(private val src: Drawable) : Drawable() {
    private val path = Path()
    private val backdrop = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF2F2F7.toInt() }

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        path.reset()
        val r = bounds.width() * 0.24f
        path.addRoundRect(RectF(bounds), r, r, Path.Direction.CW)
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val save = canvas.save()
        canvas.clipPath(path)
        if (src is AdaptiveIconDrawable) {
            val e = (b.width() * 0.25f).toInt()
            val r = Rect(b.left - e, b.top - e, b.right + e, b.bottom + e)
            src.background?.let {
                it.bounds = r
                it.draw(canvas)
            }
            src.foreground?.let {
                it.bounds = r
                it.draw(canvas)
            }
        } else {
            canvas.drawRect(RectF(b), backdrop)
            val inset = (b.width() * 0.14f).toInt()
            src.setBounds(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)
            src.draw(canvas)
        }
        canvas.restoreToCount(save)
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

fun makeAppCell(
    ctx: Context,
    app: AppInfo,
    textColor: Int,
    iconDp: Int,
    labels: Boolean,
    shadow: Boolean
): LinearLayout {
    val cell = LinearLayout(ctx)
    cell.orientation = LinearLayout.VERTICAL
    cell.gravity = Gravity.CENTER

    val icon = ImageView(ctx)
    icon.scaleType = ImageView.ScaleType.FIT_XY
    icon.setImageDrawable(SquircleIcon(app.icon))
    cell.addView(icon, LinearLayout.LayoutParams(ctx.dp(iconDp), ctx.dp(iconDp)))

    if (labels) {
        val tv = TextView(ctx)
        tv.text = app.label
        tv.setTextColor(textColor)
        tv.textSize = 11f
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.gravity = Gravity.CENTER
        if (shadow) tv.setShadowLayer(4f, 0f, 1f, 0x99000000.toInt())
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = ctx.dp(5)
        cell.addView(tv, lp)
    }
    return cell
}
