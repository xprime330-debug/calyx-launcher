package com.calyx.launcher

import android.content.Context
import android.content.SharedPreferences

/** Saved data: theme, grid size, and which apps sit on the home screen and dock. */
class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.getSharedPreferences("calyx", Context.MODE_PRIVATE)

    var theme: Int
        get() = sp.getInt("theme", Themes.DARK)
        set(value) {
            sp.edit().putInt("theme", value).apply()
        }

    var columns: Int
        get() = sp.getInt("columns", 4)
        set(value) {
            sp.edit().putInt("columns", value).apply()
        }

    var seeded: Boolean
        get() = sp.getBoolean("seeded", false)
        set(value) {
            sp.edit().putBoolean("seeded", value).apply()
        }

    var homeApps: List<String>
        get() = readList("home")
        set(value) {
            writeList("home", value)
        }

    var dockApps: List<String>
        get() = readList("dock")
        set(value) {
            writeList("dock", value)
        }

    private fun readList(key: String): List<String> {
        val raw = sp.getString(key, "") ?: ""
        return if (raw.isEmpty()) emptyList() else raw.split("\n")
    }

    private fun writeList(key: String, list: List<String>) {
        sp.edit().putString(key, list.joinToString("\n")).apply()
    }
}
