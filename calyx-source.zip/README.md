# Calyx Launcher

A clean Android home screen launcher with an original design inspired by modern iOS, One UI and Pixel launchers.

## Features (v0.1)

- Home screen pages with swipe between pages and page dots
- Floating dock (up to 4 apps)
- App drawer with live search (press Go to open the first result)
- Rounded-square icons for every app
- Light, Dark and Colorful themes, saved between launches
- 4 or 5 column grid
- Clock and date on the home screen

## Gestures

| Gesture | Action |
| --- | --- |
| Swipe up | Open app drawer |
| Swipe down (home) | Pull down notifications |
| Swipe down (drawer, at top) | Close drawer |
| Double tap | Open drawer with search ready |
| Long press empty space | Calyx settings |
| Long press an icon | Remove, add to home or dock, app info, uninstall |
| Back / Home button | Close drawer, or go to first page |

## Build

Requires JDK 17 and Gradle 8.9+.

    gradle assembleDebug

The APK is at `app/build/outputs/apk/debug/app-debug.apk`.
The included GitHub Actions workflow does this automatically on every push.

## Install

1. Install the APK (allow "install unknown apps" when asked).
2. Press the Home button, choose Calyx, tap Always.

Minimum Android version: 8.0 (API 26).

## Roadmap

- Drag and drop to rearrange icons
- Folders
- Icon packs
- Widgets
- Custom gestures and per-app hiding
